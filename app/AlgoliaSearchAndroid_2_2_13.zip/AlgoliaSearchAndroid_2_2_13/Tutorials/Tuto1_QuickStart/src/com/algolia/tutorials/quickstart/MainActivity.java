package com.algolia.tutorials.quickstart;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.AutoCompleteTextView;

import com.algolia.search.Index;
import com.algolia.search.IndexListener;
import com.algolia.search.IndexableString;
import com.algolia.search.SearchQuery;
import com.algolia.search.SearchResult;

public class MainActivity extends Activity implements IndexListener<IndexableString>, TextWatcher {
	private static String TAG = "QuickStart";
	private Index<IndexableString> index;
	private ContactAdapter adapter;
	private AutoCompleteTextView autoComplete;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        int[] subView = { R.id.hit_main };            
        adapter = new ContactAdapter(this, R.layout.hit, subView);
        autoComplete = (AutoCompleteTextView) findViewById(R.id.autoCompleteTextView);
        autoComplete.setAdapter(this.adapter);
		autoComplete.addTextChangedListener(this);
      
        File newDir = getDir("index", MODE_PRIVATE);
        newDir.mkdirs();
        String fileName = newDir.getAbsolutePath() + "/QuickStart.bin";
        File file = new File(fileName);
        if (file.exists())
        	file.delete();
        try {
        	Index.initLibrary("JwAAIGNvbS5hbGdvbGlhLnR1dG9yaWFscy5xdWlja3N0YXJ0ANsFAjAsAhQUQ0BtK+dEYcaqf8hdI7LH/vaJvAIUaiIFTV7cLhEEM0iQtbL7IxuoFtM=");
        	index = new Index<IndexableString>(this, fileName, IndexableString.class);
        	index.setHighlightPrefixSuffix("<font color='#37b1ff'><b>", "</b></font>");
        	
    		index.setEntry(new IndexableString("Kate Bell"));
    		index.setEntry(new IndexableString("Anna Haro"));
    		index.setEntry(new IndexableString("Daniel Higgins Jr."));
    		index.setEntry(new IndexableString("David Taylor"));
    		index.setEntry(new IndexableString("Hank M. Zakroff"));
    		index.publishChanges();
        	
        } catch (FileNotFoundException e) {
        	Log.e(TAG, "Could not create index: " + e.getMessage());
        }
    }
    
	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		index.asyncSearch(new SearchQuery(s.toString()));		
	}
	
	@Override
	public void searchResult(Index<IndexableString> index, SearchResult<IndexableString> result, SearchQuery query) {
		adapter.publishNewResult(index, result);
	}
	
	@Override
	public void afterTextChanged(Editable e) {
	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int before, int count) {
	}

	@Override
	public void batchSearchResults(Index<IndexableString> index,
			List<SearchResult<IndexableString>> results,
			List<SearchQuery> queries) {		
	}

	@Override
	public void publishChangesResult(Index<IndexableString> index,
			String indexFilename, boolean status) {		
	}
  
}

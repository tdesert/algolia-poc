package com.algolia.tutorials.quickstart;

import android.content.Context;
import android.text.Html;
import android.view.View;
import android.widget.TextView;

import com.algolia.search.Hit;
import com.algolia.search.Index;
import com.algolia.search.IndexableString;
import com.algolia.widget.AlgoliaSearchAdapter;

public class ContactAdapter extends AlgoliaSearchAdapter<IndexableString> {
	public ContactAdapter(Context ctx, int layout, int[] to) {
		super(ctx, layout, to);
	}
	@Override
	public void fillView(Index<IndexableString> index, Hit<IndexableString> hit, int viewId, View view) {
		if (viewId == R.id.hit_main)
			((TextView) view).setText(Html.fromHtml(index.highlight(hit.userData.value, hit).highlightedText));
	}
}

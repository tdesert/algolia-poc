package com.algolia.tutorials.indexobjects;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.algolia.search.AbstractIndexable;
import com.algolia.search.Deserializer;
import com.algolia.search.Serializer;

public class Contact extends AbstractIndexable {
	private String name;
	private String company;
	private String notes;
	
	public Contact() {}
	public Contact(String name, String company, String notes) {
		this.name = name;
		this.company = company;
		this.notes = notes;
	}
	public String getName() { return name; }
	public String getCompany() { return company; }
	public String getNotes() { return notes; }
	
	@Override
	public void deserialize(Deserializer reader, int classVersion) throws IOException {
		name = reader.readString();
		company = reader.readString();
		notes = reader.readString();
	}
	@Override
	public void serialize(Serializer writer) throws IOException {
		writer.writeString(name);
		writer.writeString(company);
		writer.writeString(notes);
	}
	@Override
	public String getUID() {
		return name;
	}
	@Override
	public List<String> textToIndex() {
		List<String> res = new ArrayList<String>(1);
		res.add(name);
		return res;
	}
}

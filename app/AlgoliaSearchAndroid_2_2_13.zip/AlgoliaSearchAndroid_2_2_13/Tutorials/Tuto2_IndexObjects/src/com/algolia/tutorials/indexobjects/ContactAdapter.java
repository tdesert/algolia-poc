package com.algolia.tutorials.indexobjects;

import android.content.Context;
import android.text.Html;
import android.view.View;
import android.widget.TextView;

import com.algolia.search.Hit;
import com.algolia.search.Index;
import com.algolia.widget.AlgoliaSearchAdapter;

public class ContactAdapter extends AlgoliaSearchAdapter<Contact> {
	public ContactAdapter(Context ctx, int layout, int[] to) {
		super(ctx, layout, to);
	}
	@Override
	public void fillView(Index<Contact> index, Hit<Contact> hit, int viewId, View view) {
		if (viewId == R.id.hit_main)
			((TextView) view).setText(Html.fromHtml(index.highlight(hit.userData.getName(), hit).highlightedText));
		else if (viewId == R.id.hit_sub) {
			if (hit.userData.getCompany() != null)
				((TextView) view).setText(hit.userData.getCompany());
			else
				((TextView) view).setText("");
		}
	}
}

package com.algolia.buildstaticindex;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;

import com.algolia.search.Index;
import com.algolia.search.IndexListener;
import com.algolia.search.SearchQuery;
import com.algolia.search.SearchResult;

public class MainActivity extends Activity implements IndexListener<City> {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		buildIndex();
	}

	/// Load content of JSON file in a string
	private String loadJSON() throws IOException {
		InputStream is = getResources().getAssets().open("GeonamesCities.json");
		
		Writer writer = new StringWriter();
		char[] buffer = new char[1024];
		try {
		    Reader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
		    int n;
		    while ((n = reader.read(buffer)) != -1) {
		        writer.write(buffer, 0, n);
		    }
		} finally {
		    is.close();
		}
		return writer.toString();
	}
	
	
	/// Build an index of cities with content of JSON file
	private void buildIndex() {
		try {
			File newDir = getDir("index", MODE_PRIVATE);
		    newDir.mkdirs();
		    String fileName = newDir.getAbsolutePath() + "/Geonames.idx";
		      
		    Index.initLibrary("IwAAHGNvbS5hbGdvbGlhLmJ1aWxkc3RhdGljaW5kZXgApQUCMC0CFE0DjbYzIpbNfOljmbQ5mCTfxCvpAhUA09U9gNScgd/5MK3FFvPQ3BXuniY=");
			Index<City> idx = new Index<City>(this, fileName, City.class);
			idx.setHitsCacheSize(50);
			
			JSONArray jArray = new JSONArray(loadJSON());
			Log.e("TAG", "" + jArray.length());
			for (int i = 0; i < jArray.length(); ++i) {
				JSONObject jObject = jArray.getJSONObject(i);
				String name = jObject.getString("Name");
				String newName = "";
				newName += name.charAt(0);
				for (int j = 1; j < name.length(); ++j)
					if (Character.toLowerCase(name.charAt(j)) != name.charAt(j) && name.charAt(j - 1) != ' ') {
						newName += Character.toLowerCase(name.charAt(j));
					} else {
						newName += name.charAt(j);
					}
				idx.setEntry(new City(newName,
									  jObject.getString("Country"), 
									  Float.valueOf(jObject.getString("Lat")),
									  Float.valueOf(jObject.getString("Long")),
									  jObject.getInt("Population")));
			}

			idx.publishChanges();
			Log.i("BuildIndex", "Index available in file: " + fileName);
		} catch (Exception e) {
			e.printStackTrace();
			Log.e("BuildStaticIndex", e.getMessage());
		}
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}

	@Override
	public void searchResult(Index<City> index, SearchResult<City> result,
			SearchQuery query) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void batchSearchResults(Index<City> index,
			List<SearchResult<City>> results, List<SearchQuery> queries) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void publishChangesResult(Index<City> index, String indexFilename,
			boolean status) {
		// TODO Auto-generated method stub
		
	}



}

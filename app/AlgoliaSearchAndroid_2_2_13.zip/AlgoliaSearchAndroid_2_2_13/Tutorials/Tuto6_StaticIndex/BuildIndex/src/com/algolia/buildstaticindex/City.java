package com.algolia.buildstaticindex;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.algolia.search.AbstractIndexable;
import com.algolia.search.Deserializer;
import com.algolia.search.Indexable;
import com.algolia.search.Serializer;

public class City extends AbstractIndexable {

	private String name;
	private String countryCode;
	private float latitude;
	private float longitude;
	private int population;
	
	public City() {
	}
	public City(String name, String countryCode, float latitude, float longitude, int population) {
		this.name = name;
		this.countryCode = countryCode;
		this.latitude = latitude;
		this.longitude = longitude;
		this.population = population;
	}
	@Override
	public void serialize(Serializer writer) throws IOException {
		writer.writeString(name);
		writer.writeString(countryCode);
		writer.writeString(Float.toString(latitude));
		writer.writeString(Float.toString(longitude));
		writer.writeUnsignedInteger(population);
	}

	@Override
	public void deserialize(Deserializer reader, int classVersion) throws IOException {
		name = reader.readString();
		countryCode = reader.readString();
		latitude = Float.valueOf(reader.readString());
		longitude = Float.valueOf(reader.readString());
		population = reader.readUnsignedInteger();		
	}

	@Override
	public int compare(Indexable other) {
		City o = (City)other;
		return o.population - population;
	}

	@Override
	public List<String> textToIndex() {
		List<String> res = new ArrayList<String>(1);
		res.add(name);
		return res;
	}
	@Override
	public String getUID() {
		return name;
	}
	@Override
	public float getLatitude() {
		return latitude;
	}
	@Override
	public float getLongitude() {
		return longitude;
	}

}

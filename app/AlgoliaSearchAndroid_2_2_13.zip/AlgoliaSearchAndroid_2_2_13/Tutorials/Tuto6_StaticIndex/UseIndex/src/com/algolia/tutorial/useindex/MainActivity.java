package com.algolia.tutorial.useindex;

import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnKeyListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;

import com.algolia.search.Index;
import com.algolia.search.IndexListener;
import com.algolia.search.SearchQuery;
import com.algolia.search.SearchResult;

public class MainActivity extends Activity implements IndexListener<City>, TextWatcher, OnKeyListener {

	private Index<City> index;
	private CityAdapter adapter;
	private AutoCompleteTextView autoComplete;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		int[] subView = { R.id.hit_main };            
	    adapter = new CityAdapter(this, R.layout.hit, subView);
	    autoComplete = (AutoCompleteTextView) findViewById(R.id.autoCompleteTextView);
	    autoComplete.setAdapter(this.adapter);
	    autoComplete.addTextChangedListener(this);
	    autoComplete.setOnKeyListener(this);
		Index.initLibrary("JAAAHWNvbS5hbGdvbGlhLnR1dG9yaWFsLnVzZWluZGV4AKUFAjAsAhQ+6ng7bS8RK2pa2efNBi4JPOfSpQIUUvmcGJ+l2xb+zvkeRFq3VQG0pTo=");
	    try {
			AssetFileDescriptor afd = getResources().getAssets().openFd("Geonames.png"); // Use png extension to be store uncompressed on all android versions.
			index = new Index<City>(this, afd, City.class);
			index.setHighlightPrefixSuffix("<font color='#37b1ff'><b>", "</b></font>");
		} catch (Exception e) {
			Log.e("UseStaticIndex", e.getMessage());
		}
	}

	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		index.asyncSearch(new SearchQuery(s.toString()));
	}
	
	@Override
	public void searchResult(Index<City> index, SearchResult<City> result, SearchQuery query) {
	    adapter.publishNewResult(index, result);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}

	@Override
	public void afterTextChanged(Editable arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
			int arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void batchSearchResults(Index<City> index,
			List<SearchResult<City>> results, List<SearchQuery> queries) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void publishChangesResult(Index<City> index, String indexFilename,
			boolean status) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean onKey(View v, int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_ENTER) {
			InputMethodManager in = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
			in.hideSoftInputFromWindow(autoComplete.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
		}
		return false;
	}
	
}

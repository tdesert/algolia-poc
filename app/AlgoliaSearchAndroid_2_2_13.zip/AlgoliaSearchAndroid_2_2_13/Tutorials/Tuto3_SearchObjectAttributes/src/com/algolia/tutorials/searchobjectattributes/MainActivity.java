package com.algolia.tutorials.searchobjectattributes;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.AutoCompleteTextView;

import com.algolia.search.Index;
import com.algolia.search.IndexListener;
import com.algolia.search.SearchQuery;
import com.algolia.search.SearchResult;

public class MainActivity extends Activity implements IndexListener<Contact>, TextWatcher {

	private static String TAG = "SearchObject";
	private Index<Contact> index;
	private ContactAdapter adapter;
	private AutoCompleteTextView autoComplete;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // Decide where we put the index and make a fresh index at startup
        File newDir = getDir("index", MODE_PRIVATE);
        newDir.mkdirs();
        String fileName = newDir.getAbsolutePath() + "/IndexObects.bin";
        File file = new File(fileName);
        if (file.exists())
        	file.delete(); 
        try {
        	// instantiates the index with Contact.class
        	Index.initLibrary("MwAALGNvbS5hbGdvbGlhLnR1dG9yaWFscy5zZWFyY2hvYmplY3RhdHRyaWJ1dGVzANsFAjAtAhQ/6i28TM2lDLzQ1XkT+iSVXXRLAQIVALuSD8FKBmZvObv1ZxSK437wzz9q");
        	index = new Index<Contact>(this, fileName, Contact.class);
        	index.setHighlightPrefixSuffix("<font color='#37b1ff'><b>", "</b></font>");
        	// Add some hardwired entries
        	index.setEntry(new Contact("Kate Bell", "Creative Consulting", "Sister: Sarah"));
    		index.setEntry(new Contact("Anna Haro", "Apple Inc", "Birthday: February 15, 2002"));
    		index.setEntry(new Contact("Daniel Higgins Jr.", "Apple Inc", "Sister: Emily"));
    		index.setEntry(new Contact("David Taylor", "Cisco", ""));
    		index.setEntry(new Contact("Hank M. Zakroff", "Financial Services Inc.", "Was working for Creative Consulting"));
    		index.publishChanges();

        } catch (FileNotFoundException e) {
        	Log.e(TAG, "Could not create index: " + e.getMessage());
        }
        int[] subView = { R.id.hit_main, R.id.hit_sub };            
        adapter = new ContactAdapter(this, R.layout.hit, subView);
        autoComplete = (AutoCompleteTextView) findViewById(R.id.autoCompleteTextView);
        autoComplete.setAdapter(this.adapter);
		autoComplete.addTextChangedListener(this);

    }
	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		index.asyncSearch(new SearchQuery(s.toString()));		
	}
	
	@Override
	public void afterTextChanged(Editable e) {
	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int before, int count) {
	}
	@Override
	public void searchResult(Index<Contact> index,
			SearchResult<Contact> result, SearchQuery query) {
		adapter.publishNewResult(index, result);
	}
	@Override
	public void batchSearchResults(Index<Contact> index,
			List<SearchResult<Contact>> results, List<SearchQuery> queries) {
	}
	@Override
	public void publishChangesResult(Index<Contact> index,
			String indexFilename, boolean status) {		
	}
  
}

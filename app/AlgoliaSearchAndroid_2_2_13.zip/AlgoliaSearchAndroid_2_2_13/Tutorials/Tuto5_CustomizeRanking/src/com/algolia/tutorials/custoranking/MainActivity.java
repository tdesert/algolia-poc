package com.algolia.tutorials.custoranking;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnKeyListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;

import com.algolia.search.HighlightResult;
import com.algolia.search.Hit;
import com.algolia.search.Index;
import com.algolia.search.IndexListener;
import com.algolia.search.RankingCriteria;
import com.algolia.search.SearchQuery;
import com.algolia.search.SearchResult;

public class MainActivity extends Activity implements IndexListener<Contact>, OnKeyListener, TextWatcher {

	private static String TAG = "CustomizeRanking";
	private Index<Contact> index;
	private ContactAdapter adapter;
	private AutoCompleteTextView autoComplete;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        File newDir = getDir("index", MODE_PRIVATE);
        newDir.mkdirs();
        String fileName = newDir.getAbsolutePath() + "/IndexObects2.bin";
        File file = new File(fileName);
        if (file.exists())
        	file.delete();
        try {
        	Index.initLibrary("KQAAImNvbS5hbGdvbGlhLnR1dG9yaWFscy5jdXN0b3JhbmtpbmcA2wUCMC4CFQC/LV4BiP29Q/f1DGKI8nz4GiWmAAIVAKibKBnKGA2OeBBpvvnP6bnaxyW7");
        	index = new Index<Contact>(this, fileName, Contact.class);
        	index.setMinWordSizeForApprox(2, 4);
        	List<RankingCriteria> sortCriteria = new ArrayList<RankingCriteria>();
        	sortCriteria.add(RankingCriteria.SCORE_INDEXING_TIME);
        	index.setRankingOrder(sortCriteria);
        	index.setHighlightPrefixSuffix("<font color='#37b1ff'><b>", "</font></b>");
    		index.setEntry(new Contact("Kate Bell", "Creative Consulting", "Sister: Sarah", 10));
    		index.setEntry(new Contact("Anna Haro", "Apple Inc", "Birthday: February 15, 2002", 5));
    		index.setEntry(new Contact("Daniel Higgins Jr.", "Apple Inc", "Sister: Emily", 3));
    		index.setEntry(new Contact("David Taylor", "Cisco", "", 0));
    		index.setEntry(new Contact("Hank M. Zakroff", "Financial Services Inc.", "Was working for Creative Consulting", 1));
    		index.publishChanges();

        } catch (FileNotFoundException e) {
        	Log.e(TAG, "Could not create index: " + e.getMessage());
        }
        int[] subView = { R.id.hit_main, R.id.hit_sub, R.id.hit_nbCalls };            
        adapter = new ContactAdapter(this, R.layout.hit, subView);
        autoComplete = (AutoCompleteTextView) findViewById(R.id.autoCompleteTextView);
        autoComplete.setAdapter(this.adapter);
		autoComplete.addTextChangedListener(this);
        autoComplete.setOnKeyListener(this);
    }
	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		if (s.length() == 2 || s.length() == 3) {
			List<SearchQuery> queries = new ArrayList<SearchQuery>();
			queries.add(new SearchQuery(s.toString()));
			if (s.length() == 2)
				queries.add(new SearchQuery("" + s.charAt(0) + " " + s.charAt(1)));
			else
				queries.add(new SearchQuery("" + s.charAt(0) + " " + s.charAt(1) + " " + s.charAt(2)));
			index.batchSearch(queries);
		} else {
			index.asyncSearch(new SearchQuery(s.toString()));
		}
	}
	
	@Override
	public void searchResult(Index<Contact> index, SearchResult<Contact> result, SearchQuery query) {
		adapter.publishNewResult(index, result);
	}
	
	@Override
	public void batchSearchResults(Index<Contact> index, List<SearchResult<Contact>> results, List<SearchQuery> queries) {
		Set<String> set = new HashSet<String>();
		List<Hit<Contact>> array = new ArrayList<Hit<Contact>>();
		for (Hit<Contact> hit : results.get(1).hits) {
			HighlightResult hr = index.highlight(hit.userData.getName(), hit);
			if (hr.textMatchedLevel == HighlightResult.Level.FULL_MATCH) {
				set.add(hit.userData.getName());
				array.add(hit);
			}
		}
		for (Hit<Contact> hit : results.get(0).hits) {
			if (!set.contains(hit.userData.getName()))
				array.add(hit);
		}
		SearchResult<Contact> newRes = new SearchResult<Contact>(array.size());
		newRes.hits = array;
		adapter.publishNewResult(index, newRes);
	}

	@Override
	public void afterTextChanged(Editable e) {
	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int before, int count) {
	}
	@Override
	public void publishChangesResult(Index<Contact> index,
			String indexFilename, boolean status) {	
	}
	@Override
	public boolean onKey(View v, int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_ENTER) {
			InputMethodManager in = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
			in.hideSoftInputFromWindow(autoComplete.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
		}
		return false;
	}
	
}

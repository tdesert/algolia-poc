package com.algolia.tutorials.custoranking;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.algolia.search.AbstractIndexable;
import com.algolia.search.Deserializer;
import com.algolia.search.Indexable;
import com.algolia.search.Serializer;

public class Contact extends AbstractIndexable {
	private String name;
	private String company;
	private String notes;
	private int nbCalls;
	
	public Contact() {}
	public Contact(String name, String company, String notes, int nbCalls) {
		this.name = name;
		this.company = company;
		this.notes = notes;
		this.nbCalls = nbCalls;
	}
	public String getName() { return name; }
	public String getCompany() { return company; }
	public String getNotes() { return notes; }
	public int getNbCalls() { return nbCalls; }
	
	@Override
	public void deserialize(Deserializer reader, int classVersion) throws IOException {
		name = reader.readString();
		company = reader.readString();
		notes = reader.readString();
		if (classVersion > 0)
			nbCalls = reader.readUnsignedInteger();
	}
	@Override
	public void serialize(Serializer writer) throws IOException {
		writer.writeString(name);
		writer.writeString(company);
		writer.writeString(notes);
		writer.writeUnsignedInteger(nbCalls);
	}

	@Override
	public List<String> textToIndex() {
		List<String> res = new ArrayList<String>(3);
		res.add(name);
		res.add(company);
		res.add(notes);
		return res;
	}
	
	@Override
	public int classVersion() {
		return 1;
	}
	@Override
	public int compare(Indexable other) {
		Contact otherContact = (Contact)other;
		return otherContact.nbCalls - nbCalls;
	}
	@Override
	public String getUID() {
		return name;
	}
}

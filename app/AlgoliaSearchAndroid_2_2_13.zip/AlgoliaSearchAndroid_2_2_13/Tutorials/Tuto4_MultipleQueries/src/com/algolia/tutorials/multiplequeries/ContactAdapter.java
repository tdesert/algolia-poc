package com.algolia.tutorials.multiplequeries;

import android.content.Context;
import android.text.Html;
import android.view.View;
import android.widget.TextView;

import com.algolia.search.HighlightResult;
import com.algolia.search.Hit;
import com.algolia.search.Index;
import com.algolia.widget.AlgoliaSearchAdapter;

public class ContactAdapter extends AlgoliaSearchAdapter<Contact> {
	
	public ContactAdapter(Context ctx, int layout, int[] to) {
		super(ctx, layout, to);
	}
	@Override
	public void fillView(Index<Contact> index, Hit<Contact> hit, int viewId, View view) {
		if (viewId == R.id.hit_main) {
			HighlightResult hr = index.highlight(hit.userData.getName(), hit);
			((TextView) view).setText(Html.fromHtml(hr.highlightedText));
		} else if (viewId == R.id.hit_sub) {
			HighlightResult hr = index.highlight(hit.userData.getCompany(), hit);
			if (hr.textMatchedLevel != HighlightResult.Level.NO_MATCH) {
				((TextView) view).setText(Html.fromHtml("Company: " + hr.highlightedText));
			} else {
				 hr = index.highlight(hit.userData.getNotes(), hit);
				 if (hr.textMatchedLevel != HighlightResult.Level.NO_MATCH) {
						((TextView) view).setText(Html.fromHtml("Notes: " + hr.highlightedText));
				 } else {
					 ((TextView) view).setText("Company: " + hit.userData.getCompany());
				 }
			}
		}
	}
}

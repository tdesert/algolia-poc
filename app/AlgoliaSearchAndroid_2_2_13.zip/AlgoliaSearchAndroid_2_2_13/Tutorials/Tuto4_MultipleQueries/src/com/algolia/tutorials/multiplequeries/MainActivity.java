package com.algolia.tutorials.multiplequeries;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.AutoCompleteTextView;

import com.algolia.search.HighlightResult;
import com.algolia.search.Hit;
import com.algolia.search.Index;
import com.algolia.search.IndexListener;
import com.algolia.search.SearchQuery;
import com.algolia.search.SearchResult;

public class MainActivity extends Activity implements IndexListener<Contact>, TextWatcher {

	private static String TAG = "MultipleQueries";
	private Index<Contact> index;
	private ContactAdapter adapter;
	private AutoCompleteTextView autoComplete;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        File newDir = getDir("index", MODE_PRIVATE);
        newDir.mkdirs();
        String fileName = newDir.getAbsolutePath() + "/IndexObects.bin";
        File file = new File(fileName);
        if (file.exists())
        	file.delete();
        try {
        	Index.initLibrary("LAAAJWNvbS5hbGdvbGlhLnR1dG9yaWFscy5tdWx0aXBsZXF1ZXJpZXMA2wUCMC4CFQCnt2yHr7l+tpeJZoHDq4uFEsxTRAIVAJ72wqvCKAnOsuw9E88QXUE+yAWD");
        	index = new Index<Contact>(this, fileName, Contact.class);
        	index.setHighlightPrefixSuffix("<font color='#37b1ff'><b>", "</b></font>");
    		index.setEntry(new Contact("Kate Bell", "Creative Consulting", "Sister: Sarah"));
    		index.setEntry(new Contact("Anna Haro", "Apple Inc", "Birthday: February 15, 2002"));
    		index.setEntry(new Contact("Daniel Higgins Jr.", "Apple Inc", "Sister: Emily"));
    		index.setEntry(new Contact("David Taylor", "Cisco", ""));
    		index.setEntry(new Contact("Hank M. Zakroff", "Financial Services Inc.", "Was working for Creative Consulting"));
    		index.publishChanges();

        } catch (FileNotFoundException e) {
        	Log.e(TAG, "Could not create index: " + e.getMessage());
        }
        int[] subView = { R.id.hit_main, R.id.hit_sub };            
        adapter = new ContactAdapter(this, R.layout.hit, subView);
        autoComplete = (AutoCompleteTextView) findViewById(R.id.autoCompleteTextView);
        autoComplete.setAdapter(this.adapter);
		autoComplete.addTextChangedListener(this);
      
    }
	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		if (s.length() == 2 || s.length() == 3) {
		    List<SearchQuery> queries = new ArrayList<SearchQuery>();
		    // Add original query
		    queries.add(new SearchQuery(s.toString()));
		    if (s.length() == 2) {
		      // split "ab" in "a b"
		      queries.add(new SearchQuery("" + s.charAt(0) + " " + 
		                  s.charAt(1)));
		    } else {
		      // split "abc" in "a b c"
		      queries.add(new SearchQuery("" + s.charAt(0) + " " + 
		                  s.charAt(1) + " " + s.charAt(2)));
		    }
		    // launch two queries in one call
		    index.batchSearch(queries);
		  } else {
		    index.asyncSearch(new SearchQuery(s.toString()));
		  }
	}
	
	@Override
	public void searchResult(Index<Contact> index, SearchResult<Contact> result, SearchQuery query) {
		adapter.publishNewResult(index, result);
	}
	
	@Override
	public void batchSearchResults(Index<Contact> index, List<SearchResult<Contact>> results, List<SearchQuery> queries) {
		// Set used for dedup (key = name)
		Set<String> set = new HashSet<String>();
		// Array that contains the results of 2 queries without duplicate
		List<Hit<Contact>> array = new ArrayList<Hit<Contact>>();
		// Scan results of second query (rewritten query)
		for (Hit<Contact> hit : results.get(1).hits) {
			HighlightResult hr = index.highlight(hit.userData.getName(), hit);
			// Add the hit only if the name fully match the query
			if (hr.textMatchedLevel == HighlightResult.Level.FULL_MATCH) {
				set.add(hit.userData.getName());
				array.add(hit);
			}
		}
		// Scan results of original query
		for (Hit<Contact> hit : results.get(0).hits) {
			if (!set.contains(hit.userData.getName()))
				array.add(hit);
		}
		SearchResult<Contact> newRes = new SearchResult<Contact>(array.size());
		newRes.hits = array;
		adapter.publishNewResult(index, newRes);
	}	

	@Override
	public void afterTextChanged(Editable e) {
	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int before, int count) {
	}
	@Override
	public void publishChangesResult(Index<Contact> index,
			String indexFilename, boolean status) {		
	}
  
}

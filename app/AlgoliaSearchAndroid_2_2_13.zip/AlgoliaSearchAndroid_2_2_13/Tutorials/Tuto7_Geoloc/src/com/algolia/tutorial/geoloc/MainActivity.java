package com.algolia.tutorial.geoloc;

import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;

import com.algolia.search.Index;
import com.algolia.search.IndexListener;
import com.algolia.search.SearchQuery;
import com.algolia.search.SearchResult;

public class MainActivity extends Activity implements IndexListener<City>, TextWatcher, OnKeyListener, LocationListener {

	private Index<City> index;
	private CityAdapter adapter;
	private AutoCompleteTextView autoComplete;
	private LocationManager locationManager;
	private float lastLatitude;
	private float lastLongitude;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		int[] subView = { R.id.hit_main, R.id.hit_dist };            
	    adapter = new CityAdapter(this, R.layout.hit, subView);
	    autoComplete = (AutoCompleteTextView) findViewById(R.id.autoCompleteTextView);
	    autoComplete.setAdapter(this.adapter);
	    autoComplete.addTextChangedListener(this);
	    autoComplete.setOnKeyListener(this);
	    locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
	    final boolean gpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
	    assert(gpsEnabled);
	    locationManager.requestLocationUpdates( LocationManager.GPS_PROVIDER, 3000, 0, this);
	    lastLatitude = lastLongitude = 0;
	    Location l = locationManager.getLastKnownLocation(locationManager.GPS_PROVIDER);
	    lastLatitude = (float)l.getLatitude();
	    lastLongitude = (float)l.getLongitude();

		try {
			Index.initLibrary("IgAAG2NvbS5hbGdvbGlhLnR1dG9yaWFsLmdlb2xvYwDOBgIwLQIUdUuXhJR+Q3ara6LmD4phDC0Nta8CFQC2PgnlYQhX4Otn0RdwKe3CakjXeA==");
			AssetFileDescriptor afd = getResources().getAssets().openFd("Geonames.png"); // Use png extension to be store uncompressed on all android versions.
			index = new Index<City>(this, afd, City.class);
			index.setHighlightPrefixSuffix("<font color='#37b1ff'><b>", "</b></font>");
		} catch (Exception e) {
			Log.e("UseStaticIndex: file not found", e.getMessage());
			throw new RuntimeException(e);
		}
	}

	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		SearchQuery query = new SearchQuery(s.toString());
		query.setGeolocQuery(lastLatitude, lastLongitude, 100000);
		index.asyncSearch(query);
	}
	
	@Override
	public void searchResult(Index<City> index, SearchResult<City> result, SearchQuery query) {
	    adapter.publishNewResult(index, result);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}

	@Override
	public void onLocationChanged(Location loc) {
		SearchQuery q = new SearchQuery(autoComplete.getText().toString());
		lastLatitude = (float)loc.getLatitude();
		lastLongitude = (float)loc.getLongitude();
		q.setGeolocQuery(lastLatitude, lastLongitude, 100000);
		index.asyncSearch(q);
	}
	@Override
	public boolean onKey(View v, int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_ENTER) {
			InputMethodManager in = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
			in.hideSoftInputFromWindow(autoComplete.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
		}
		return false;
	}
	
	@Override
	public void afterTextChanged(Editable arg0) {
		
	}

	@Override
	public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
			int arg3) {
		
	}

	@Override
	public void batchSearchResults(Index<City> index,
			List<SearchResult<City>> results, List<SearchQuery> queries) {
	
	}

	@Override
	public void publishChangesResult(Index<City> index, String indexFilename,
			boolean status) {
		
	}
	
	@Override
	public void onProviderDisabled(String arg0) {
		
	}

	@Override
	public void onProviderEnabled(String arg0) {
		
	}

	@Override
	public void onStatusChanged(String arg0, int arg1, Bundle arg2) {
		
	}
	
}

package com.algolia.tutorial.geoloc;

import android.content.Context;
import android.text.Html;
import android.view.View;
import android.widget.TextView;

import com.algolia.search.Hit;
import com.algolia.search.Index;
import com.algolia.widget.AlgoliaSearchAdapter;

public class CityAdapter extends AlgoliaSearchAdapter<City> {
	  public CityAdapter(Context ctx, int layout, int[] to) {
	    super(ctx, layout, to);
	  }
	  @Override
	  public void fillView(Index<City> index, Hit<City> hit, int viewId, View view) {
	    if (viewId == R.id.hit_main)
	      ((TextView) view).setText(Html.fromHtml(index.highlight(hit.userData.getName(), hit).highlightedText));
	    else if (viewId == R.id.hit_dist)
	      ((TextView) view).setText(String.format("%.1f km", (float)hit.geoDistance / 1000f));
	  }
}

$('.carousel').each(function(){
    var lis = $(this).find('li')
    var index = 0
    var current_li = lis[index]

    $(current_li).addClass('active')
    if (lis.length < 2) {
        return
    }
    
    $(this).find('.next').click(function(e){
        e.preventDefault()
        clearInterval(interval)
        index += 1
        if (index >= lis.length) {
            index = 0
        }
        show_picture(lis[index])
    })

    $(this).find('.previous').click(function(e){
        e.preventDefault()
        clearInterval(interval)
        index -= 1
        if (index < 0){
            index = lis.length - 1
        }
        show_picture(lis[index])
    })
    
    function show_picture(li){
        $(current_li).removeClass('active')
        current_li = li
        $(current_li).addClass('active')
        $(this).css({'height': $(current_li).height()})
    }
    var interval = setInterval(function() {
        index = ++index % lis.length
        show_picture(lis[index])
    }, 5000)          
})

$("a[data-target=fancybox]").fancybox();

$(window).load(function() {
  $('body').scrollspy('refresh');
});
$('.collapse').on('hidden', function () {
  $('body').scrollspy('refresh');
});
$('.collapse').on('shown', function () {
  $('body').scrollspy('refresh');
});


$('[data-toggle="modal"]').click(function(e) {
    e.preventDefault();
    var url = $(this).attr('href');
    if (url.indexOf('#') == 0) {
        $(url).modal('open');
    } else {
        $.get(url, function(data) {
            $('<div class="modal hide fade">' + data + '</div>').modal();
        }).success(function() { $('input:text:visible:first').focus(); });
    }
});

$('body').on('submit', 'form[ajax-form]', function(e){
    e.preventDefault();
    var form = this
    $.ajax({
        type: "POST",
        url: $(this).attr('action'),
        data: $(this).serialize(),
        success: function(response) {
            console.log('success', this)
            $(form).replaceWith($(response));
        }
    });
})
